import colors from "./colors"
const lightBorder = `1px solid black`

export {lightBorder}