export const colors={
   fontColor:'#ffffff'
}