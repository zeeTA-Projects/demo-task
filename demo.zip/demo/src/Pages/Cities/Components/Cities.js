import React from 'react';

function Cities(props) {
    return (
        <div>
            <h1>List of cities</h1>
        </div>
    );
}

export default Cities;