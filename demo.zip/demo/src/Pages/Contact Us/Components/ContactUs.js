import React from 'react';

function ContactUs(props) {
    return (
        <div>
            <h1>Contact us form</h1>
        </div>
    );
}

export default ContactUs;