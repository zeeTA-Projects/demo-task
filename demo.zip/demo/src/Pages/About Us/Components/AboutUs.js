import React from 'react';

function AboutUs(props) {
    return (
        <div>
            <h1>About us page</h1>
        </div>
    );
}

export default AboutUs;